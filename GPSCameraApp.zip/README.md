# GPS Camera (Android, Kotlin)

Features:
- CameraX live preview, flash toggle, front/back switch, zoom slider
- Capture photo, stamp GPS + date/time + custom text on image
- Save to MediaStore (Pictures/GPSCamera), quality selectable
- Room DB to store photo metadata
- Gallery grid (Coil) to preview saved images
- Settings screen (font size, color hex, GPS format, custom text)

## Build
- Open in Android Studio (Min SDK 24, Target 35)
- Sync Gradle
- Run on device, allow Camera/Location/Photos permissions

## Notes
- Reverse geocoding runs on capture (not during live overlay).
- Add your own launcher icons if desired.
