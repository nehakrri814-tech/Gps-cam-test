package com.smart.gpscamera
import android.app.Application
class App : Application()
