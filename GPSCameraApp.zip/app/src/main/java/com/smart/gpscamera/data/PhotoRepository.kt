package com.smart.gpscamera.data
import android.content.Context
import com.smart.gpscamera.data.db.AppDatabase
import com.smart.gpscamera.data.db.PhotoEntity

class PhotoRepository(context: Context) {
    private val dao = AppDatabase.get(context).photoDao()
    suspend fun insert(e: PhotoEntity) = dao.insert(e)
    suspend fun getAll() = dao.getAll()
}
