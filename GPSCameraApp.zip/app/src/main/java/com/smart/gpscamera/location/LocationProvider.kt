package com.smart.gpscamera.location
import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import com.google.android.gms.location.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.*

class LocationProvider(private val context: Context) {
    private val client = LocationServices.getFusedLocationProviderClient(context)

    @SuppressLint("MissingPermission")
    fun locationFlow() = callbackFlow<Location?> {
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L).build()
        val cb = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) { trySend(result.lastLocation) }
        }
        client.requestLocationUpdates(req, cb, context.mainLooper)
        awaitClose { client.removeLocationUpdates(cb) }
    }

    suspend fun reverseGeocode(lat: Double, lon: Double): String? {
        return runCatching {
            val geocoder = Geocoder(context, Locale.getDefault())
            val list = geocoder.getFromLocation(lat, lon, 1)
            list?.firstOrNull()?.let { "${it.locality ?: it.subAdminArea}, ${it.adminArea}" }
        }.getOrNull()
    }

    @SuppressLint("MissingPermission")
    suspend fun lastKnown(): Location? = client.lastLocation.await()
}
