package com.smart.gpscamera.prefs
import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("settings")

class SettingsStore(private val context: Context) {
    companion object {
        val KEY_CUSTOM_TEXT = stringPreferencesKey("custom_text")
        val KEY_FONT_SIZE = intPreferencesKey("font_size")
        val KEY_COLOR_HEX = stringPreferencesKey("color_hex")
        val KEY_GPS_FORMAT_PLACE = booleanPreferencesKey("gps_place")
        val KEY_QUALITY_HIGH = booleanPreferencesKey("quality_high")
    }

    suspend fun save(custom: String, fontSize: Int, colorHex: String, placeFormat: Boolean, highQuality: Boolean) {
        context.dataStore.updateData {
            it.toMutablePreferences().apply {
                this[KEY_CUSTOM_TEXT] = custom
                this[KEY_FONT_SIZE] = fontSize
                this[KEY_COLOR_HEX] = colorHex
                this[KEY_GPS_FORMAT_PLACE] = placeFormat
                this[KEY_QUALITY_HIGH] = highQuality
            }
        }
    }

    suspend fun read(): Settings =
        context.dataStore.data.map { p ->
            Settings(
                customText = p[KEY_CUSTOM_TEXT] ?: "",
                fontSizeSp = p[KEY_FONT_SIZE] ?: 16,
                colorHex = p[KEY_COLOR_HEX] ?: "#FFFFFF",
                gpsPlaceFormat = p[KEY_GPS_FORMAT_PLACE] ?: false,
                highQuality = p[KEY_QUALITY_HIGH] ?: true
            )
        }.first()
}

data class Settings(
    val customText: String,
    val fontSizeSp: Int,
    val colorHex: String,
    val gpsPlaceFormat: Boolean,
    val highQuality: Boolean
)
