package com.smart.gpscamera.ui
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class FlowObserver<T>(
    private val activity: AppCompatActivity,
    private val flow: StateFlow<T>,
    private val onEach: (T)->Unit
): DefaultLifecycleObserver {
    private var job: Job? = null
    override fun onStart(owner: LifecycleOwner) {
        job = MainScope().launch { flow.collect { onEach(it) } }
    }
    override fun onStop(owner: LifecycleOwner) { job?.cancel(); job = null }
}
