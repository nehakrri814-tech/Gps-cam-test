package com.smart.gpscamera.ui
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import coil.load
import com.smart.gpscamera.databinding.ActivityGalleryBinding
import com.smart.gpscamera.databinding.ItemPhotoBinding
import com.smart.gpscamera.ui.gallery.GalleryViewModel
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.smart.gpscamera.data.db.PhotoEntity

class GalleryActivity : AppCompatActivity() {
    private lateinit var b: ActivityGalleryBinding
    private val vm: GalleryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(b.root)

        val adapter = PhotoAdapter()
        b.rvPhotos.layoutManager = GridLayoutManager(this, 3)
        b.rvPhotos.adapter = adapter

        vm.items.collectWithLifecycle(this) { adapter.submit(it) }
        vm.load(this)
    }

    private fun <T> kotlinx.coroutines.flow.StateFlow<T>.collectWithLifecycle(
        activity: AppCompatActivity, onEach: (T)->Unit
    ) {
        activity.lifecycle.addObserver(FlowObserver(activity, this, onEach))
    }

    private class PhotoAdapter : RecyclerView.Adapter<VH>() {
        private val data = mutableListOf<PhotoEntity>()
        fun submit(list: List<PhotoEntity>) { data.clear(); data.addAll(list); notifyDataSetChanged() }
        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(ItemPhotoBinding.inflate(LayoutInflater.from(p.context), p, false))
        override fun getItemCount() = data.size
        override fun onBindViewHolder(h: VH, i: Int) { h.bind(data[i]) }
    }
    private class VH(val b: ItemPhotoBinding): RecyclerView.ViewHolder(b.root) {
        fun bind(item: PhotoEntity) { b.img.load(item.uri) }
    }
}
