package com.smart.gpscamera.ui
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.smart.gpscamera.databinding.ActivitySettingsBinding
import com.smart.gpscamera.prefs.SettingsStore
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {
    private lateinit var b: ActivitySettingsBinding
    private lateinit var store: SettingsStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        store = SettingsStore(this)

        lifecycleScope.launch {
            val s = store.read()
            b.etCustomText.setText(s.customText)
            b.etFontSize.setText(s.fontSizeSp.toString())
            b.etColorHex.setText(s.colorHex)
            b.rgGps.check(if (s.gpsPlaceFormat) b.rbPlace.id else b.rbLatLong.id)
            b.rgQuality.check(if (s.highQuality) b.rbHigh.id else b.rbLow.id)
        }

        b.btnSaveSettings.setOnClickListener {
            lifecycleScope.launch {
                val font = b.etFontSize.text.toString().toIntOrNull() ?: 16
                store.save(
                    b.etCustomText.text.toString(),
                    font,
                    b.etColorHex.text.toString().ifBlank { "#FFFFFF" },
                    b.rgGps.checkedRadioButtonId == b.rbPlace.id,
                    b.rgQuality.checkedRadioButtonId == b.rbHigh.id
                )
                finish()
            }
        }
    }
}
