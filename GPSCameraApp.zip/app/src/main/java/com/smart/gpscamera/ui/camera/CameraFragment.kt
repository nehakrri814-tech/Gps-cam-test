package com.smart.gpscamera.ui.camera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.view.*
import android.widget.SeekBar
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.smart.gpscamera.databinding.FragmentCameraBinding
import com.smart.gpscamera.location.LocationProvider
import com.smart.gpscamera.prefs.SettingsStore
import com.smart.gpscamera.ui.GalleryActivity
import com.smart.gpscamera.ui.SettingsActivity
import com.smart.gpscamera.util.ImageStampUtil
import com.smart.gpscamera.data.PhotoRepository
import com.smart.gpscamera.data.db.PhotoEntity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class CameraFragment : Fragment() {

    private var _b: FragmentCameraBinding? = null
    private val b get() = _b!!

    private val vm: CameraViewModel by viewModels()
    private lateinit var settingsStore: SettingsStore
    private lateinit var locationProvider: LocationProvider

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var flashMode = ImageCapture.FLASH_MODE_AUTO

    private val exec = Executors.newSingleThreadExecutor()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?) =
        FragmentCameraBinding.inflate(inflater, container, false).also { _b = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        settingsStore = SettingsStore(requireContext())
        locationProvider = LocationProvider(requireContext())

        b.btnSettings.setOnClickListener {
            startActivity(Intent(requireContext(), SettingsActivity::class.java))
        }
        b.btnGallery.setOnClickListener {
            startActivity(Intent(requireContext(), GalleryActivity::class.java))
        }
        b.btnSwitchCamera.setOnClickListener {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            startCamera()
        }
        b.btnFlash.setOnClickListener {
            flashMode = when (flashMode) {
                ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_OFF
                else -> ImageCapture.FLASH_MODE_AUTO
            }
            imageCapture?.flashMode = flashMode
        }

        b.zoomSeek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                camera?.cameraControl?.setLinearZoom(p/100f)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        b.btnShutter.setOnClickListener { takePhoto() }

        lifecycleScope.launch {
            while (true) {
                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                vm.tick(sdf.format(Date()))
                kotlinx.coroutines.delay(1000)
            }
        }

        lifecycleScope.launch {
            if (hasPerm(Manifest.permission.ACCESS_FINE_LOCATION))
                locationProvider.locationFlow().collectLatest { vm.setLocation(it) }
        }

        lifecycleScope.launch { vm.setSettings(settingsStore.read()) }
        lifecycleScope.launch { vm.timeText.collectLatest { renderOverlay() } }
        lifecycleScope.launch { vm.location.collectLatest { renderOverlay() } }
        lifecycleScope.launch { vm.settings.collectLatest { renderOverlay() } }
    }

    override fun onResume() {
        super.onResume()
        startCamera()
        lifecycleScope.launch { vm.setSettings(settingsStore.read()) }
    }

    private fun startCamera() {
        val ctx = requireContext()
        val providerFuture = ProcessCameraProvider.getInstance(ctx)
        providerFuture.addListener({
            val provider = providerFuture.get()
            provider.unbindAll()

            val preview = Preview.Builder().build().apply {
                setSurfaceProvider(b.previewView.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder()
                .setFlashMode(flashMode)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            camera = provider.bindToLifecycle(viewLifecycleOwner, selector, preview, imageCapture)

        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun renderOverlay() {
        val s = vm.settings.value ?: return
        val time = vm.timeText.value
        val loc = vm.location.value
        val lines = mutableListOf<String>()
        if (loc != null) {
            if (s.gpsPlaceFormat) {
                lines += String.format(Locale.getDefault(), "Lat: %.5f, Lon: %.5f", loc.latitude, loc.longitude)
            } else {
                lines += String.format(Locale.getDefault(), "Lat: %.5f, Lon: %.5f", loc.latitude, loc.longitude)
            }
            if (loc.hasAltitude()) lines += "Alt: ${"%.1f".format(loc.altitude)} m"
        } else {
            lines += "Locating..."
        }
        lines += time
        if (s.customText.isNotBlank()) lines += s.customText

        b.stampOverlay.lines = lines
        b.stampOverlay.color = runCatching { Color.parseColor(s.colorHex) }.getOrDefault(Color.WHITE)
        b.stampOverlay.fontSizeSp = s.fontSizeSp.toFloat()
    }

    private fun takePhoto() {
        val cap = imageCapture ?: return
        val outFile = requireContext().cacheDir.resolve("temp_${System.currentTimeMillis()}.jpg")
        val outputOpts = ImageCapture.OutputFileOptions.Builder(outFile).build()

        cap.takePicture(outputOpts, exec, object: ImageCapture.OnImageSavedCallback{
            override fun onError(exc: ImageCaptureException) { exc.printStackTrace() }
            override fun onImageSaved(res: ImageCapture.OutputFileResults) {
                val file = outFile
                val base = android.graphics.BitmapFactory.decodeFile(file.absolutePath) ?: return
                val set = vm.settings.value ?: return
                val loc: Location? = vm.location.value
                val lines = mutableListOf<String>()
                if (loc != null) {
                    if (set.gpsPlaceFormat) {
                        val place = runCatching {
                            kotlinx.coroutines.runBlocking {
                                LocationProvider(requireContext()).reverseGeocode(loc.latitude, loc.longitude)
                            }
                        }.getOrNull()
                        lines += (place ?: String.format(Locale.getDefault(), "Lat: %.5f, Lon: %.5f", loc.latitude, loc.longitude))
                    } else {
                        lines += String.format(Locale.getDefault(), "Lat: %.5f, Lon: %.5f", loc.latitude, loc.longitude)
                    }
                    if (loc.hasAltitude()) lines += "Alt: ${"%.1f".format(loc.altitude)} m"
                }
                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                lines += sdf.format(Date())
                if (set.customText.isNotBlank()) lines += set.customText

                val color = runCatching { Color.parseColor(set.colorHex) }.getOrDefault(Color.WHITE)
                val stamped: Bitmap = com.smart.gpscamera.util.ImageStampUtil.drawStamp(
                    base, com.smart.gpscamera.util.ImageStampUtil.StampData(lines, color, set.fontSizeSp)
                )
                val uri = com.smart.gpscamera.util.ImageStampUtil.saveToGallery(requireContext(), stamped, set.highQuality)

                if (uri != null) {
                    val repo = com.smart.gpscamera.data.PhotoRepository(requireContext())
                    kotlinx.coroutines.runBlocking {
                        repo.insert(
                            com.smart.gpscamera.data.db.PhotoEntity(
                                uri = uri,
                                latitude = loc?.latitude,
                                longitude = loc?.longitude,
                                address = null,
                                timestamp = System.currentTimeMillis()
                            )
                        )
                    }
                }
            }
        })
    }

    private fun hasPerm(p: String) =
        ActivityCompat.checkSelfPermission(requireContext(), p) == PackageManager.PERMISSION_GRANTED
}
