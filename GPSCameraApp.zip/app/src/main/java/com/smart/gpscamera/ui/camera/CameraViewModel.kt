package com.smart.gpscamera.ui.camera
import android.location.Location
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.smart.gpscamera.prefs.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class CameraViewModel : ViewModel() {
    private val _location = MutableStateFlow<Location?>(null)
    val location: StateFlow<Location?> = _location
    private val _settings = MutableStateFlow<Settings?>(null)
    val settings: StateFlow<Settings?> = _settings
    val timeText = MutableStateFlow("")
    fun setLocation(loc: Location?) { _location.value = loc }
    fun setSettings(s: Settings) { _settings.value = s }
    fun tick(time: String) = viewModelScope.launch { timeText.emit(time) }
}
