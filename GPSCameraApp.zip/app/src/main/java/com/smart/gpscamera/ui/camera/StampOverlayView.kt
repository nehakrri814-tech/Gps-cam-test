package com.smart.gpscamera.ui.camera
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class StampOverlayView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {
    var lines: List<String> = emptyList()
        set(value) { field = value; invalidate() }
    var color: Int = Color.WHITE
        set(value) { field = value; invalidate() }
    var fontSizeSp: Float = 16f
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        setShadowLayer(4f, 2f, 2f, Color.BLACK)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (lines.isEmpty()) return
        paint.color = color
        paint.textSize = sp(fontSizeSp)
        val pad = width * 0.04f
        var y = height - pad
        for (line in lines.asReversed()) {
            canvas.drawText(line, pad, y, paint)
            y -= paint.textSize * 1.3f
        }
    }

    private fun sp(sp: Float): Float = sp * resources.displayMetrics.scaledDensity
}
