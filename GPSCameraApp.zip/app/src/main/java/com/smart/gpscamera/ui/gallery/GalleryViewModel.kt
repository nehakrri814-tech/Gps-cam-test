package com.smart.gpscamera.ui.gallery
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.smart.gpscamera.data.PhotoRepository
import com.smart.gpscamera.data.db.PhotoEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class GalleryViewModel : ViewModel() {
    private val _items = MutableStateFlow<List<PhotoEntity>>(emptyList())
    val items = _items.asStateFlow()
    fun load(context: Context) = viewModelScope.launch {
        val repo = PhotoRepository(context)
        _items.value = repo.getAll()
    }
}
