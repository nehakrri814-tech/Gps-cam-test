package com.smart.gpscamera.util
import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.os.Build
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.*

object ImageStampUtil {
    data class StampData(val textLines: List<String>, val color: Int, val fontSizeSp: Int)

    fun drawStamp(base: Bitmap, stamp: StampData): Bitmap {
        val out = base.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = stamp.color
            textSize = spToPx(base, stamp.fontSizeSp)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            setShadowLayer(4f, 2f, 2f, Color.BLACK)
        }
        val pad = out.width * 0.02f
        var y = out.height - pad
        for (line in stamp.textLines.asReversed()) {
            canvas.drawText(line, pad, y, paint)
            y -= paint.textSize * 1.3f
        }
        return out
    }

    private fun spToPx(bmp: Bitmap, sp: Int): Float = (bmp.width / 1080f) * sp * 3.0f

    fun nowFileName(): String {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        return "GPS_${sdf.format(Date())}.jpg"
    }

    fun saveToGallery(context: Context, bmp: Bitmap, highQuality: Boolean): String? {
        val name = nowFileName()
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GPSCamera")
            }
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { out ->
            bmp.compress(Bitmap.CompressFormat.JPEG, if (highQuality) 92 else 70, out)
        }
        return uri.toString()
    }
}
